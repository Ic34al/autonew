from motor.motor_asyncio import AsyncIOMotorClient
from bot import Var
import datetime 
import asyncio
import re

class MongoDB:
    def __init__(self, uri, database_name):
        self.__client = AsyncIOMotorClient(uri)
        self.__db = self.__client[database_name]
        self.__animes = self.__db.animes[Var.BOT_TOKEN.split(':')[0]]
        self.__anime_channels = self.__db.anime_channels
        self.__manga_channels = self.__db.manga_channels
        self.__manga_banners = self.__db.manga_banners
        self.__ffmpeg_configs = self.__db.ffmpeg_configs

    async def add_user(self, user_id: int):
        await self.__db.users.update_one({'_id': user_id}, {'$set': {'_id': user_id}}, upsert=True)

    async def saveAnimePost(self, ani_id, ep, post_id):
        if ani_id is None or ep is None or post_id is None:
            return

        await self.__animes.update_one(
            {"_id": ani_id},
            {"$set": {f"{str(ep)}.msg_id": int(post_id)}},
            upsert=True,
        )

    async def saveAnimeDedicatedPost(self, ani_id, ep, post_id):
        if ani_id is None or ep is None or post_id is None:
            return
        await self.__animes.update_one(
            {"_id": ani_id},
            {"$set": {f"{str(ep)}.dedicated_msg_id": int(post_id)}},
            upsert=True,
        )

    async def saveAnimeMainPost(self, ani_id, ep, main_post_id):
        if ani_id is None or ep is None or main_post_id is None:
            return

        await self.__animes.update_one(
            {"_id": ani_id},
            {"$set": {f"{str(ep)}.main_msg_id": int(main_post_id)}},
            upsert=True,
        )

    async def saveAnimeDestinationPost(self, ani_id, ep, channel_id, post_id):
        if ani_id is None or ep is None or channel_id is None or post_id is None:
            return
        await self.__animes.update_one(
            {"_id": ani_id},
            {"$set": {f"{str(ep)}.destination_posts.{int(channel_id)}": int(post_id)}},
            upsert=True,
        )

    async def getAnimeDestinationPost(self, ani_id, ep, channel_id):
        if ani_id is None or ep is None or channel_id is None:
            return None
        anime_data = await self.__animes.find_one(
            {"_id": ani_id},
            {f"{str(ep)}.destination_posts.{int(channel_id)}": 1},
        )
        if not anime_data:
            return None
        episode_data = anime_data.get(str(ep), {})
        posts = episode_data.get("destination_posts", {}) if isinstance(episode_data, dict) else {}
        return posts.get(str(int(channel_id))) if isinstance(posts, dict) else None

    async def getAnimeMainPost(self, ani_id, ep):
        if ani_id is None or ep is None:
            return None

        anime_data = await self.__animes.find_one(
            {"_id": ani_id},
            {f"{str(ep)}.main_msg_id": 1},
        )

        if not anime_data:
            return None

        episode_data = anime_data.get(str(ep), {})
        if not isinstance(episode_data, dict):
            return None

        # Older releases stored the Main Channel message ID as msg_id.
        return episode_data.get("main_msg_id") or episode_data.get("msg_id")
    async def claimAnimeEpisode(self, ani_id, ep, token):
        """Claim an episode globally across all bot workers."""
        if ani_id is None or ep is None:
            return True

        key = f"anime:{ani_id}:episode:{str(ep)}"
        now = datetime.datetime.utcnow()
        expires = now + datetime.timedelta(hours=12)

        try:
            await self.__db.episode_locks.update_one(
                {
                    "_id": key,
                    "$or": [
                        {"expires_at": {"$exists": False}},
                        {"expires_at": {"$lte": now}},
                    ],
                },
                {
                    "$set": {
                        "token": token,
                        "expires_at": expires,
                    }
                },
                upsert=True,
            )
            return True

        except Exception as e:
            # An active lock already owns this episode.
            if "duplicate key" in str(e).lower() or "E11000" in str(e):
                return False

            raise

    async def releaseAnimeEpisode(self, ani_id, ep, token):
        if ani_id is None or ep is None or not token:
            return

        key = f"anime:{ani_id}:episode:{str(ep)}"

        await self.__db.episode_locks.delete_one(
            {
                "_id": key,
                "token": token,
            }
        )
    async def saveAnimeFileId(self, ani_id, ep, qual, file_id):
        """Save Telegram file-store message ID for an episode quality."""
        if ani_id is None or ep is None or not qual or file_id is None:
            return

        await self.__animes.update_one(
            {"_id": ani_id},
            {"$set": {f"{str(ep)}.file_ids.{qual}": int(file_id)}},
            upsert=True,
        )

    async def getAnimeFileIds(self, ani_id, ep):
        """Get saved Telegram file IDs for an episode."""
        if ani_id is None or ep is None:
            return {}

        anime_data = await self.__animes.find_one(
            {"_id": ani_id},
            {f"{str(ep)}.file_ids": 1},
        )

        if not anime_data:
            return {}

        episode_data = anime_data.get(str(ep), {})
        if not isinstance(episode_data, dict):
            return {}

        file_ids = episode_data.get("file_ids", {})
        return file_ids if isinstance(file_ids, dict) else {}

    async def saveAnimeResume(self, ani_id, ep, name, torrent_url, destination_channel=None):
        """Persist an unfinished episode and its resolved destination for restart recovery."""
        if ani_id is None or ep is None or not torrent_url:
            return
        key = f"{ani_id}:{str(ep)}"
        update = {
            "ani_id": ani_id,
            "episode": str(ep),
            "name": str(name),
            "torrent_url": str(torrent_url),
            "status": "pending",
            "updated_at": datetime.datetime.utcnow(),
        }
        if destination_channel is not None:
            update["destination_channel"] = int(destination_channel)
        await self.__db.anime_resume.update_one(
            {"_id": key},
            {"$set": update},
            upsert=True,
        )

    async def getAnimeResumeTasks(self):
        """Return unfinished episodes in creation order for serial recovery."""
        cursor = self.__db.anime_resume.find({"status": {"$ne": "complete"}}).sort("updated_at", 1)
        return await cursor.to_list(length=100)

    async def saveManualSearchTask(self, batch_id, anime_name, position, title, torrent_url, destination_channel):
        """Persist every selected /search episode before starting the batch."""
        task_id = f"{str(batch_id)}:{int(position)}"
        now = datetime.datetime.utcnow()
        await self.__db.manual_search_queue.update_one(
            {"_id": task_id},
            {"$setOnInsert": {
                "batch_id": str(batch_id),
                "anime_name": str(anime_name),
                "position": int(position),
                "title": str(title),
                "torrent_url": str(torrent_url),
                "destination_channel": int(destination_channel),
                "status": "pending",
                "created_at": now,
            }},
            upsert=True,
        )
        return task_id

    async def getPendingManualSearchTasks(self):
        """Return only explicitly selected manual /search episodes, never scanner tasks."""
        cursor = self.__db.manual_search_queue.find(
            {"status": "pending"}
        ).sort([("created_at", 1), ("position", 1)])
        return await cursor.to_list(length=500)

    async def markManualSearchTaskComplete(self, task_id):
        if not task_id:
            return
        await self.__db.manual_search_queue.update_one(
            {"_id": str(task_id), "status": "pending"},
            {"$set": {
                "status": "complete",
                "completed_at": datetime.datetime.utcnow(),
            }},
        )

    async def markAnimeResumeComplete(self, ani_id, ep):
        if ani_id is None or ep is None:
            return
        await self.__db.anime_resume.update_one(
            {"_id": f"{ani_id}:{str(ep)}"},
            {"$set": {"status": "complete", "completed_at": datetime.datetime.utcnow()}},
        )
    async def markMessageManuallyEdited(self, chat_id, message_id, caption=None):
        """Remember channel posts edited by an admin so automated edits never overwrite them."""
        if chat_id is None or message_id is None:
            return
        update = {
            "chat_id": int(chat_id),
            "message_id": int(message_id),
            "edited_at": datetime.datetime.utcnow(),
        }
        if caption is not None:
            update["caption"] = str(caption)
        await self.__db.manual_channel_edits.update_one(
            {"_id": f"{int(chat_id)}:{int(message_id)}"},
            {"$set": update},
            upsert=True,
        )

    async def isMessageManuallyEdited(self, chat_id, message_id):
        if chat_id is None or message_id is None:
            return False
        record = await self.__db.manual_channel_edits.find_one(
            {"_id": f"{int(chat_id)}:{int(message_id)}"},
            {"_id": 1},
        )
        return bool(record)

    async def saveAnimeStatus(self, ani_id, ep, status_msg_id):
        if ani_id is None or ep is None or status_msg_id is None:
            return

        await self.__animes.update_one(
            {"_id": ani_id},
            {
                "$set": {
                    f"{str(ep)}.status_msg_id": int(status_msg_id)
                }
            },
            upsert=True,
        )
    async def getAnime(self, ani_id):
        if ani_id is None:
            return {}

        anime_data = await self.__animes.find_one({"_id": ani_id})

        if not anime_data:
            return {}

        anime_data.pop("_id", None)
        return anime_data
    async def saveAnime(self, ani_id, ep, qual, post_id=None, gdrive_link=None):
        if ani_id is None:
            return

        ep = str(ep if ep is not None else "default_ep")
        allowed_quals = list(Var.QUALS) + ["HDRi", "pdf"]

        if qual not in allowed_quals:
            print(f"Error: Invalid quality type ({qual})")
            return

        update_data = {
            f"{ep}.{qual}": True,
            f"{ep}.timestamp": datetime.datetime.now(),
        }

        if gdrive_link:
            update_data[f"{ep}.{qual}_gdrive"] = gdrive_link

        if post_id is not None:
            update_data[f"{ep}.msg_id"] = int(post_id)
        try:
            await self.__animes.update_one(
                {"_id": ani_id},
                {"$set": update_data},
                upsert=True,
            )
            print(f"Successfully updated anime {ani_id}, episode {ep}, quality {qual}")
        except Exception as e:
            print(f"Error updating anime {ani_id}, episode {ep}: {e}")
            raise
        
    async def add_anime_channel_mapping(self, anime_name: str, channel: str | int):
        """Create or update the dedicated channel mapping for an anime."""
        normalized_name = re.sub(r"\s+", " ", str(anime_name).lower()).strip()
        if not normalized_name:
            raise ValueError("Anime name cannot be empty")

        channel_id = int(channel) if str(channel).lstrip("-").isdigit() else str(channel).strip()
        await self.__anime_channels.update_one(
            {"anime_name": normalized_name},
            {"$set": {"anime_name": normalized_name, "channel_id": channel_id}},
            upsert=True,
        )


    async def set_anime_channel_invite_link(self, anime_name: str, channel_id: int, invite_link: str):
        key = re.sub(r"\s+", " ", str(anime_name).casefold()).strip()
        if not key or not invite_link:
            raise ValueError("Anime name and invite link are required")
        await self.__anime_channels.update_one(
            {"anime_name": key},
            {"$set": {"anime_name": key, "channel_id": int(channel_id), "invite_link": str(invite_link)}},
            upsert=True,
        )
        await self.__db.selected_anime_channels.update_one(
            {"_id": key},
            {"$set": {"anime_name": key, "channel_id": int(channel_id), "invite_link": str(invite_link), "enabled": True}},
            upsert=True,
        )

    async def get_anime_channel_invite_link(self, anime_name: str):
        key = re.sub(r"\s+", " ", str(anime_name).casefold()).strip()
        record = await self.__anime_channels.find_one({"anime_name": key})
        if record and record.get("invite_link"):
            return record["invite_link"]
        selected = await self.__db.selected_anime_channels.find_one({"_id": key})
        return (selected or {}).get("invite_link")

    async def remove_anime_channel_mapping(self, anime_name: str, channel: str | int | None = None):
        query = {"anime_name": anime_name.lower()}
        if channel is not None:
            query["channel_id"] = int(channel) if str(channel).lstrip("-").isdigit() else channel
        await self.__anime_channels.delete_many(query)

    async def get_anime_channel(self, anime_name: str) -> int | None:
        """Resolve both legacy and current /addanime records using safe normalized aliases."""
        def compact(value):
            return "".join(ch for ch in str(value or "").casefold() if ch.isalnum())

        def series_key(value):
            value = str(value or "").casefold()
            value = re.sub(r"\bseason\s*\d+\b|\bs\s*\d{1,2}\b", " ", value)
            value = re.sub(r"\b(?:episode|ep)\s*[-._ ]*\d+\b", " ", value)
            value = re.sub(r"\b(?:part|cour)\s*\d+\b", " ", value)
            return compact(value)

        target = compact(anime_name)
        base_target = series_key(anime_name)
        if not target:
            return None

        exact_channels, series_channels, token_channels = set(), set(), set()
        ignored = {"the", "a", "an", "of", "and", "to"}
        target_tokens = {t for t in re.findall(r"[a-z0-9]+", str(anime_name).casefold()) if t not in ignored}
        async for entry in self.__anime_channels.find():
            if not isinstance(entry, dict):
                continue
            stored_name = entry.get("anime_name") or entry.get("name") or entry.get("anime")
            channel_id = entry.get("channel_id") or entry.get("channel") or entry.get("destination")
            if not stored_name or channel_id is None:
                continue
            stored_key = compact(stored_name)
            stored_series = series_key(stored_name)
            normalized_channel = int(channel_id) if str(channel_id).lstrip("-").isdigit() else str(channel_id).strip()
            if stored_key == target:
                exact_channels.add(normalized_channel)
            if base_target and stored_series == base_target:
                series_channels.add(normalized_channel)
            stored_tokens = {t for t in re.findall(r"[a-z0-9]+", str(stored_name).casefold()) if t not in ignored}
            if len(target_tokens) >= 3 and len(stored_tokens) >= 3:
                overlap = len(target_tokens & stored_tokens)
                if overlap >= 3 and overlap / max(1, min(len(target_tokens), len(stored_tokens))) >= 0.8:
                    token_channels.add(normalized_channel)

        if len(exact_channels) == 1:
            return next(iter(exact_channels))
        if len(exact_channels) > 1:
            return None
        if len(series_channels) == 1:
            return next(iter(series_channels))
        if len(series_channels) > 1:
            return None
        if len(token_channels) == 1:
            return next(iter(token_channels))
        return None

    async def get_raw_anime_channel(self, anime_name: str) -> dict | None:
        try:
            entry = await self.__anime_channels.find_one({"anime_name": anime_name.lower()})
            return entry
        except Exception as e:
            print(f"Error fetching raw anime channel entry for {anime_name}: {e}")
            return None
        
    async def get_all_anime_channels(self):
        try:
            anime_channels = await self.__anime_channels.find().to_list(length=None)
            if not anime_channels:
                return {}
                
            valid_channels = []
            for entry in anime_channels:
                try:
                    if isinstance(entry, dict) and 'anime_name' in entry and 'channel_id' in entry:
                        anime_name = str(entry['anime_name'])
                        channel_id = str(entry['channel_id'])
                        valid_channels.append((anime_name, channel_id))
                except Exception as e:
                    print(f"Error processing channel entry: {e}")
                    continue
          
            try:
                sorted_channels = sorted(
                    valid_channels,
                    key=lambda x: (":" not in x[0], x[0])
                )
                return dict(sorted_channels) if sorted_channels else {}
            except Exception as e:
                print(f"Error sorting anime channels: {e}")
                return {}
        except Exception as e:
            print(f"Error fetching anime channels: {e}")
            return {}

    async def set_anime_channel_selected(self, anime_name: str, channel_id: int):
        key = re.sub(r"\s+", " ", str(anime_name).lower()).strip()
        await self.__db.selected_anime_channels.update_one(
            {"_id": key}, {"$set": {"anime_name": key, "channel_id": int(channel_id), "enabled": True}}, upsert=True
        )

    async def set_batch_file_link(self, token: str, message_ids):
        clean_ids = [int(message_id) for message_id in message_ids]
        await self.__db.batch_file_links.update_one(
            {"_id": str(token)},
            {"$set": {"message_ids": clean_ids, "updated_at": datetime.datetime.utcnow()}},
            upsert=True,
        )

    async def get_batch_file_link(self, token: str):
        record = await self.__db.batch_file_links.find_one({"_id": str(token)})
        return (record or {}).get("message_ids", [])

    async def get_anime_archive_batch(self, anime_id: int, season_number: int, channel_id: int):
        key = f"{int(anime_id)}:{int(season_number)}:{int(channel_id)}"
        return await self.__db.anime_archive_batches.find_one({"_id": key})

    async def set_anime_archive_batch(
        self, anime_id: int, season_number: int, channel_id: int,
        status: str, torrent_url: str = "", release_title: str = "",
    ):
        if status not in ("in_progress", "complete", "failed"):
            raise ValueError("Invalid archive batch status")
        key = f"{int(anime_id)}:{int(season_number)}:{int(channel_id)}"
        now = datetime.datetime.utcnow()
        await self.__db.anime_archive_batches.update_one(
            {"_id": key},
            {"$set": {
                "anime_id": int(anime_id),
                "season_number": int(season_number),
                "channel_id": int(channel_id),
                "status": status,
                "torrent_url": str(torrent_url or ""),
                "release_title": str(release_title or ""),
                "updated_at": now,
            }, "$setOnInsert": {"created_at": now}},
            upsert=True,
        )

    async def get_selected_anime_channel(self, anime_name: str):
        key = re.sub(r"\s+", " ", str(anime_name).lower()).strip()
        doc = await self.__db.selected_anime_channels.find_one({"_id": key, "enabled": True})
        return doc.get("channel_id") if doc else None

    async def list_selected_anime_channels(self):
        return await self.__db.selected_anime_channels.find({"enabled": True}).sort("anime_name", 1).to_list(length=None)

    async def remove_selected_anime_channel(self, anime_name: str):
        key = re.sub(r"\s+", " ", str(anime_name).lower()).strip()
        result = await self.__db.selected_anime_channels.update_one({"_id": key}, {"$set": {"enabled": False}})
        return result.modified_count > 0

    async def set_api_source(self, api_name: str):
        await self.__db.settings.update_one({"_id": "api_source"}, {"$set": {"api": api_name}}, upsert=True)

    async def get_api_source(self) -> str:
        doc = await self.__db.settings.find_one({"_id": "api_source"})
        api = doc["api"] if doc and "api" in doc else "anilist"
        if api not in ("anilist", "v2", "jikan"):
            api = "anilist"
        return api

    async def set_anime_banner(self, anime_name: str, banner_url: str):
        await self.__anime_channels.update_one(
            {"anime_name": anime_name.lower()},
            {"$set": {"banner_url": banner_url}},
            upsert=True
        )

    async def get_anime_banner(self, anime_name: str) -> str | None:
        entry = await self.__anime_channels.find_one({"anime_name": anime_name.lower()})
        return entry["banner_url"] if entry and "banner_url" in entry else None

    async def del_anime_banner(self, anime_name: str):
        await self.__anime_channels.update_one(
            {"anime_name": anime_name.lower()},
            {"$unset": {"banner_url": ""}}
        )

    async def list_anime_banners(self):
        banners = []
        async for doc in self.__anime_channels.find({"banner_url": {"$exists": True}}):
            banners.append((doc["anime_name"], doc["banner_url"]))
        return banners

    async def set_backup_channel(self, channel: int | str):
        await self.__db.settings.update_one({"_id": "backup_channel"}, {"$set": {"channel_id": channel}}, upsert=True)

    async def get_backup_channel(self) -> int | str | None:
        doc = await self.__db.settings.find_one({"_id": "backup_channel"})
        return doc.get("channel_id") if doc and "channel_id" in doc else None

    async def del_backup_channel(self):
        await self.__db.settings.delete_one({"_id": "backup_channel"})

    async def set_backup_mode(self, mode: str):
        if mode not in ("archive", "sep"):
            raise ValueError("Invalid backup mode")
        await self.__db.settings.update_one({"_id": "backup_mode"}, {"$set": {"value": mode}}, upsert=True)

    async def get_backup_mode(self) -> str:
        doc = await self.__db.settings.find_one({"_id": "backup_mode"})
        return doc.get("value") if doc and "value" in doc else "archive"

    async def add_backup_mapping(self, main_chat: int, main_msg_id: int, backup_chat: int, backup_msg_id: int):
        await self.__db.backup_mappings.update_one(
            {"main_chat": int(main_chat), "main_msg_id": int(main_msg_id)},
            {"$set": {
                "backup_chat": int(backup_chat),
                "backup_msg_id": int(backup_msg_id),
                "updated_at": datetime.datetime.now()
            }},
            upsert=True
        )

    async def get_backup_mapping(self, main_chat: int, main_msg_id: int):
        try:
            doc = await self.__db.backup_mappings.find_one({"main_chat": int(main_chat), "main_msg_id": int(main_msg_id)})
            return doc
        except Exception as e:
            print(f"Error fetching backup mapping: {e}")
            return None

    async def add_pending_backup(self, main_chat: int, main_msg_id: int):
        try:
            await self.__db.pending_backups.update_one(
                {"main_chat": int(main_chat), "main_msg_id": int(main_msg_id)},
                {"$set": {"pending": True, "created_at": datetime.datetime.now()}},
                upsert=True
            )
        except Exception as e:
            print(f"Error adding pending backup: {e}")

    async def get_pending_backup(self, main_chat: int, main_msg_id: int):
        try:
            doc = await self.__db.pending_backups.find_one({"main_chat": int(main_chat), "main_msg_id": int(main_msg_id)})
            return doc
        except Exception as e:
            print(f"Error fetching pending backup: {e}")
            return None

    async def del_pending_backup(self, main_chat: int, main_msg_id: int):
        try:
            await self.__db.pending_backups.delete_one({"main_chat": int(main_chat), "main_msg_id": int(main_msg_id)})
        except Exception as e:
            print(f"Error deleting pending backup: {e}")

    async def delete_backup_mapping(self, main_chat: int, main_msg_id: int):
        try:
            await self.__db.backup_mappings.delete_one({"main_chat": int(main_chat), "main_msg_id": int(main_msg_id)})
        except Exception as e:
            print(f"Error deleting backup mapping: {e}")
        
    async def set_global_thumb(self, file_id: str):
        await self.__db.settings.update_one({"_id": "global_thumb"}, {"$set": {"file_id": file_id}}, upsert=True)

    async def get_global_thumb(self) -> str | None:
        doc = await self.__db.settings.find_one({"_id": "global_thumb"})
        return doc["file_id"] if doc and "file_id" in doc else None

    async def del_global_thumb(self):
        await self.__db.settings.delete_one({"_id": "global_thumb"})

    async def set_auto_del(self, value: bool):
        await self.__db.settings.update_one({"_id": "auto_del"}, {"$set": {"value": value}}, upsert=True)

    async def get_auto_del(self) -> bool:
        doc = await self.__db.settings.find_one({"_id": "auto_del"})
        return doc["value"] if doc and "value" in doc else Var.AUTO_DEL

    async def set_del_timer(self, value: int):
        await self.__db.settings.update_one({"_id": "del_timer"}, {"$set": {"value": value}}, upsert=True)

    async def get_del_timer(self) -> int:
        doc = await self.__db.settings.find_one({"_id": "del_timer"})
        return doc["value"] if doc and "value" in doc else Var.DEL_TIMER

    async def set_sticker_id(self, sticker_id: str):
        await self.__db.settings.update_one({"_id": "sticker_id"}, {"$set": {"value": sticker_id}}, upsert=True)

    async def get_sticker_id(self) -> str | None:
        doc = await self.__db.settings.find_one({"_id": "sticker_id"})
        return doc["value"] if doc and "value" in doc else None

    async def del_sticker_id(self):
        await self.__db.settings.delete_one({"_id": "sticker_id"})

    async def set_start_photo(self, value: str):
        await self.__db.settings.update_one({"_id": "start_photo"}, {"$set": {"value": value}}, upsert=True)

    async def get_start_photo(self) -> str | None:
        doc = await self.__db.settings.find_one({"_id": "start_photo"})
        return doc["value"] if doc and "value" in doc else None

    async def set_schedule_photo(self, value: str):
        await self.__db.settings.update_one({"_id": "schedule_photo"}, {"$set": {"value": value}}, upsert=True)

    async def get_schedule_photo(self) -> str | None:
        doc = await self.__db.settings.find_one({"_id": "schedule_photo"})
        return doc["value"] if doc and "value" in doc else None

    async def set_force_photo(self, value: str):
        await self.__db.settings.update_one({"_id": "force_photo"}, {"$set": {"value": value}}, upsert=True)

    async def get_force_photo(self) -> str | None:
        doc = await self.__db.settings.find_one({"_id": "force_photo"})
        return doc["value"] if doc and "value" in doc else None

    async def set_send_schedule(self, value: bool):
        await self.__db.settings.update_one({"_id": "send_schedule"}, {"$set": {"value": value}}, upsert=True)

    async def get_send_schedule(self) -> bool:
        doc = await self.__db.settings.find_one({"_id": "send_schedule"})
        return doc["value"] if doc and "value" in doc else Var.SEND_SCHEDULE

    @property
    def fsub(self):
        return self.__db.fsub

    async def add_fsub(self, channel_id: int):
        await self.fsub.update_one({'_id': channel_id}, {'$set': {'_id': channel_id}}, upsert=True)

    async def del_fsub(self, channel_id: int):
        await self.fsub.delete_one({'_id': channel_id})

    async def list_fsubs(self):
        """
        Return only valid Telegram chat identifiers.
        Older/invalid documents may have MongoDB ObjectId values in _id;
        Pyrogram cannot use those as chat identifiers.
        """
        docs = await self.fsub.find().to_list(length=None)
        chat_ids = []
        for doc in docs:
            value = doc.get("channel_id", doc.get("_id"))
            if isinstance(value, bool):
                continue
            if isinstance(value, int):
                chat_ids.append(value)
            elif isinstance(value, str):
                value = value.strip()
                if not value:
                    continue
                if value.lstrip("-").isdigit():
                    chat_ids.append(int(value))
                elif value.startswith("@"):
                    chat_ids.append(value)
        return list(dict.fromkeys(chat_ids))

    async def set_fsub_mode(self, channel_id: int, mode: str):
        await self.fsub.update_one({'_id': channel_id}, {'$set': {'mode': mode}}, upsert=True)

    async def get_fsub_mode(self, channel_id: int) -> str:
        doc = await self.fsub.find_one({'_id': channel_id})
        return doc.get('mode', 'normal') if doc else 'normal'

    async def list_fsubs_with_mode(self):
        docs = await self.fsub.find().to_list(length=None)
        return [(doc['_id'], doc.get('mode', 'normal')) for doc in docs]

    async def set_channel_creation(self, value: bool):
        await self.__db.settings.update_one({"_id": "channel_creation"}, {"$set": {"enabled": value}}, upsert=True)

    async def get_channel_creation(self) -> bool:
        doc = await self.__db.settings.find_one({"_id": "channel_creation"})
        return doc.get("enabled", False) if doc else False

    async def set_encoding(self, value: bool):
        await self.__db.settings.update_one({"_id": "encoding"}, {"$set": {"enabled": value}}, upsert=True)

    async def get_encoding(self) -> bool:
        doc = await self.__db.settings.find_one({"_id": "encoding"})
        return doc.get("enabled", True) if doc else True

    async def set_mode(self, mode: str):
        await self.__db.settings.update_one({"_id": "mode"}, {"$set": {"value": mode}}, upsert=True)

    async def get_mode(self) -> str:
        doc = await self.__db.settings.find_one({"_id": "mode"})
        return doc["value"] if doc and "value" in doc else "anime"

    async def add_manga_channel_mapping(self, manga_name: str, channel: str):
        await self.__manga_channels.update_one(
            {"manga_name": manga_name.lower()},
            {"$set": {"channel_id": channel}},
            upsert=True
        )

    async def remove_manga_channel_mapping(self, manga_name: str, channel: str | int | None = None):
        query = {"manga_name": manga_name.lower()}
        if channel is not None:
            query["channel_id"] = int(channel) if str(channel).lstrip("-").isdigit() else channel
        await self.__manga_channels.delete_one(query)

    async def get_manga_channel(self, manga_name: str) -> int | None:
        entry = await self.__manga_channels.find_one({"manga_name": manga_name.lower()})
        return entry["channel_id"] if entry else None
        
    async def get_all_manga_channels(self):
        try:
            manga_channels = await self.__manga_channels.find().to_list(length=None)
            return {entry['manga_name']: entry['channel_id'] for entry in manga_channels if 'channel_id' in entry}
        except Exception as e:
            print(f"Error fetching manga channels: {e}")
            return {}

    async def set_manga_banner(self, manga_name: str, banner_url: str):
        await self.__manga_banners.update_one(
            {"manga_name": manga_name.lower()},
            {"$set": {"banner_url": banner_url}},
            upsert=True
        )

    async def get_manga_banner(self, manga_name: str) -> str | None:
        entry = await self.__manga_banners.find_one({"manga_name": manga_name.lower()})
        return entry["banner_url"] if entry else None

    async def del_manga_banner(self, manga_name: str):
        await self.__manga_banners.delete_one({"manga_name": manga_name.lower()})

    async def list_manga_banners(self):
        banners = await self.__manga_banners.find().to_list(length=None)
        return [(banner["manga_name"], banner["banner_url"]) for banner in banners]

    async def set_anime_ffmpeg(self, anime_name: str, ffmpeg_config: str):
        await self.__ffmpeg_configs.update_one(
            {"anime_name": anime_name.lower()},
            {"$set": {"config": ffmpeg_config}},
            upsert=True
        )

    async def get_anime_ffmpeg(self, anime_name: str) -> str | None:
        entry = await self.__ffmpeg_configs.find_one({"anime_name": anime_name.lower()})
        return entry["config"] if entry else None

    async def del_anime_ffmpeg(self, anime_name: str):
        await self.__ffmpeg_configs.delete_one({"anime_name": anime_name.lower()})

    async def list_anime_ffmpeg(self):
        configs = await self.__ffmpeg_configs.find().to_list(length=None)
        return [(config["anime_name"], config["config"]) for config in configs]

    async def set_global_ffmpeg(self, config_key: str, ffmpeg_config: str):
        await self.__db.settings.update_one(
            {"_id": f"ffmpeg_{config_key}"},
            {"$set": {"config": ffmpeg_config}},
            upsert=True
        )

    async def get_global_ffmpeg(self, config_key: str) -> str | None:
        doc = await self.__db.settings.find_one({"_id": f"ffmpeg_{config_key}"})
        return doc["config"] if doc else None

    async def del_global_ffmpeg(self, config_key: str):
        await self.__db.settings.delete_one({"_id": f"ffmpeg_{config_key}"})

    async def set_upload_mode(self, mode: str):
        await self.__db.settings.update_one(
            {"_id": "upload_mode"},
            {"$set": {"mode": mode}},
            upsert=True
        )

    async def get_upload_mode(self) -> str:
        doc = await self.__db.settings.find_one({"_id": "upload_mode"})
        return doc["mode"] if doc else "high_end"

    async def set_low_end_rename(self, value: bool):
        await self.__db.settings.update_one({"_id": "low_end_rename"}, {"$set": {"enabled": value}}, upsert=True)

    async def get_low_end_rename(self) -> bool:
        doc = await self.__db.settings.find_one({"_id": "low_end_rename"})
        return doc.get("enabled", True) if doc else True

    async def save_rss_link(self, link_type: str, rss_link: str, quality: str = None):
        doc = {"type": link_type, "link": rss_link}
        if quality:
            doc["quality"] = quality
        await self.__db.rss_links.update_one(
            doc,
            {"$set": doc},
            upsert=True
        )

    async def mark_episode_completed(self, ani_id, ep):
        if ep is None:
            ep = "default_ep"
        ep = str(ep)
        try:
            await self.__animes.update_one(
                {'_id': ani_id},
                {'$set': {f"{ep}.completed": True}},
                upsert=True
            )
            print(f"Marked anime {ani_id} episode {ep} as completed")
        except Exception as e:
            print(f"Error marking episode as completed: {e}")

    async def save_rss_links_bulk(self, links: list[dict]):
        if not links:
            return
        operations = []
        for link in links:
            doc = {"type": link["type"], "link": link["link"]}
            if "quality" in link and link["quality"]:
                doc["quality"] = link["quality"]
            operations.append(
                self.__db.rss_links.update_one(
                    doc,
                    {"$set": doc},
                    upsert=True
                )
            )
        await asyncio.gather(*operations)

    async def add_specific_manga(self, manga_name: str):
        try:
            await self.__db.specific_mangas.update_one(
                {"_id": manga_name.lower()},
                {"$set": {"name": manga_name.lower(), "added_at": datetime.datetime.now()}},
                upsert=True,
            )
        except Exception as e:
            print(f"Error adding specific manga {manga_name}: {e}")

    async def get_specific_manga(self, manga_name: str) -> bool:
        try:
            doc = await self.__db.specific_mangas.find_one({"_id": manga_name.lower()})
            return doc is not None
        except Exception as e:
            print(f"Error checking specific manga {manga_name}: {e}")
            return False

    async def del_specific_manga(self, manga_name: str):
        try:
            await self.__db.specific_mangas.delete_one({"_id": manga_name.lower()})
        except Exception as e:
            print(f"Error deleting specific manga {manga_name}: {e}")

    async def list_specific_mangas(self) -> list:
        try:
            docs = await self.__db.specific_mangas.find().to_list(length=None)
            return [d.get("name") for d in docs if d and "name" in d]
        except Exception as e:
            print(f"Error listing specific mangas: {e}")
            return []

    async def delete_all_specific_mangas(self):
        try:
            await self.__db.specific_mangas.delete_many({})
        except Exception as e:
            print(f"Error deleting all specific mangas: {e}")

    async def set_manga_check_mode(self, mode: str):
        try:
            await self.__db.settings.update_one({"_id": "manga_check_mode"}, {"$set": {"value": mode}}, upsert=True)
        except Exception as e:
            print(f"Error setting manga_check_mode to {mode}: {e}")

    async def get_manga_check_mode(self) -> str:
        try:
            doc = await self.__db.settings.find_one({"_id": "manga_check_mode"})
            return doc.get("value") if doc and "value" in doc else "latest"
        except Exception as e:
            print(f"Error getting manga_check_mode: {e}")
            return "latest"

    async def add_admin(self, user_id: int):
        await self.__db.settings.update_one(
            {"_id": "admins"},
            {"$addToSet": {"ids": user_id}},
            upsert=True
        )

    async def get_admins(self):
        doc = await self.__db.settings.find_one({"_id": "admins"})
        return doc.get("ids", []) if doc else []
    
    async def remove_admin(self, user_id: int):
        await self.__db.settings.update_one(
            {"_id": "admins"},
            {"$pull": {"ids": user_id}}
        )

    async def delete_rss_link(self, link_type: str, link: str):
        await self.__db.rss_links.delete_one({"type": link_type, "link": link})

    async def delete_all_ffmpeg_configs(self):
        await self.__ffmpeg_configs.delete_many({})

    async def delete_all_anime_mappings(self):
        await self.__anime_channels.delete_many({})

    async def delete_all_anime_banners(self):
        await self.__anime_channels.update_many({}, {"$unset": {"banner_url": ""}})

    async def get_users_count(self):
        users = await self.__db.users.count_documents({}) if "users" in await self.__db.list_collection_names() else 0
        return users

    async def get_all_users(self):
        if "users" not in await self.__db.list_collection_names():
            return []
        users = await self.__db.users.find().to_list(length=None)
        return [u["_id"] for u in users if "_id" in u]

    async def get_all_rss_links(self):
        cursor = self.__db.rss_links.find({})
        links = []
        async for doc in cursor:
            links.append(doc)
        return links

    async def set_gdrive_upload(self, status: str):
        await self.__db.settings.update_one({"_id": "gdrive_upload"}, {"$set": {"status": status}}, upsert=True)

    async def get_gdrive_upload(self) -> str:
        doc = await self.__db.settings.find_one({"_id": "gdrive_upload"})
        if doc and "status" in doc:
            return doc["status"]
        from bot import Var
        return getattr(Var, "GDRIVE_UPLOAD", "off")

    async def set_fontchanger(self, status: str):
        await self.__db.settings.update_one({"_id": "fontchanger"}, {"$set": {"status": status}}, upsert=True)

    async def get_fontchanger(self) -> str:
        doc = await self.__db.settings.find_one({"_id": "fontchanger"})
        if doc and "status" in doc:
            return doc["status"]
        from bot import Var
        return getattr(Var, "FONTCHANGER", "off")

    async def delete_all_manga_mappings(self):
        await self.__manga_channels.delete_many({})

    async def delete_all_manga_banners(self):
        await self.__manga_banners.delete_many({})
      
    async def add_gdrive_mapping(self, anime_name: str, quality: str, gdrive_link: str):

        from bot.core.auto_animes import get_all_possible_anime_names
        possible_names = await get_all_possible_anime_names(anime_name)
        for name in possible_names:
            await self.__db.gdrive_mappings.update_one(
                {"anime_name": name.lower(), "quality": quality},
                {"$set": {
                    "gdrive_link": gdrive_link,
                    "added_at": datetime.datetime.now(),
                    "name_no_colon": name.lower().replace(":", "").replace("  ", " ").strip()
                }},
                upsert=True
            )

    async def get_gdrive_mapping(self, anime_name: str, quality: str) -> str | None:
        input_name = anime_name.lower()
        input_name_no_colon = input_name.replace(":", "").replace("  ", " ").strip()
        
        doc = await self.__db.gdrive_mappings.find_one({
            "anime_name": input_name,
            "quality": quality
        })
        if doc:
            return doc["gdrive_link"]
            
        cursor = self.__db.gdrive_mappings.find({"quality": quality})
        async for doc in cursor:
            stored_name = doc["anime_name"]
            stored_no_colon = doc.get("name_no_colon") or stored_name.replace(":", "").replace("  ", " ").strip()

            if ":" in stored_name:
                if input_name_no_colon == stored_no_colon:
                    return doc["gdrive_link"]
            else:
                if stored_name in input_name:
                    return doc["gdrive_link"]
                    
        return None

    async def delete_gdrive_mapping(self, anime_name: str, quality: str):
        from bot.core.auto_animes import get_all_possible_anime_names
        possible_names = await get_all_possible_anime_names(anime_name)
        for name in possible_names:
            await self.__db.gdrive_mappings.delete_one({"anime_name": name.lower(), "quality": quality})

    async def reboot(self):
        await self.__animes.drop()

    async def delete_anime_by_id(self, ani_id):
        if ani_id is not None:
            await self.__animes.delete_one({"_id": ani_id})

    async def add_processed_url(self, url: str):
        await self.__db.processed_urls.update_one({'_id': url}, {'$set': {'_id': url}}, upsert=True)

    async def is_processed_url(self, url: str) -> bool:
        doc = await self.__db.processed_urls.find_one({'_id': url})
        return doc is not None

    async def clear_processed_urls(self):
        await self.__db.processed_urls.delete_many({})

db = MongoDB(Var.MONGO_URI, Var.MONGO_NAME) 
