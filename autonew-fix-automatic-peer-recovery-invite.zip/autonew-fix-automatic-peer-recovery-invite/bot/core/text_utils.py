import httpx
from calendar import month_name
from datetime import datetime
from random import choice
from asyncio import sleep as asleep
from aiohttp import ClientSession, ClientTimeout
from anitopy import parse
import re
from bot import Var, bot
from .ffargs import ffargs
from .func_utils import handle_logs
from .reporter import rep
from .database import db
import asyncio

_manga_anilist_lock = asyncio.Lock()
_manga_anilist_last_call = 0
_anime_anilist_lock = asyncio.Lock()
_anime_anilist_last_call = 0

MANUAL_ANILIST_NAMES = {
    "Im Living With an Otaku NEET Kunoichi": "I'm Living With an Otaku NEET Kunoichi"
}

CAPTION_FORMAT = """
<blockquote><b>❐<i> {title} </i></b></blockquote>
<b>✦─━━━━━━━━━━─✦</b>
<b>›› Sᴇᴀꜱᴏɴ: {anime_season}</b>
<b>›› Eᴘɪsᴏᴅᴇ: {ep_no}</b>
<b>››Qᴜᴀʟɪᴛʏ : {quality_label}</b>
<b>›› Lᴀɴɢᴜᴀɢᴇ: {lang}</b>
<b>✦─━━━━━━━━━━─✦</b>
<blockquote><b>≡ Sᴛᴀᴛᴜꜱ: {status}</b></blockquote>
<blockquote><b>≡ Pᴏᴡᴇʀᴇᴅ Bʏ : <a href='https://t.me/Ongoing_Anime_Time'>Ongoing Anime Time</a></b></blockquote>
<b>✦─━━━━━━━━━━─✦</b>
<blockquote><b>≡ Hᴏᴡ Tᴏ Dᴏᴡɴʟᴏᴀᴅ? - <a href='https://t.me/+y6wpSaZzvk0xYjQ9'>Wᴀᴛᴄʜ Nᴏᴡ</a></b></blockquote>
<blockquote><b>≡ ᴜꜱᴇ <a href='https://play.google.com/store/apps/details?id=com.mxtech.videoplayer.ad'>vlc player</a> or <a href='https://play.google.com/store/apps/details?id=com.mxtech.videoplayer.ad'>mx player</a> ᴛᴏ ᴄʜᴀɴɢᴇ ᴀᴜᴅɪᴏ ᴀɴᴅ ꜱᴜʙᴛɪᴛʟᴇꜱ ꜰᴏʀ ᴀ ʙᴇᴛᴛᴇʀ ᴠɪᴇᴡɪɴɢ ᴇxᴩᴇʀɪᴇɴᴄᴇ.</b></blockquote>
"""

MOVIE_CAPTION = """
<blockquote><b>❐<i> {title} </i></b></blockquote>
<b>✦─━━━━━━━━━━─✦</b>
<b>›› Sᴇᴀꜱᴏɴ: {anime_season}</b>
<b>›› Eᴘɪsᴏᴅᴇ: {ep_no}</b>
<b>›› Qᴜᴀʟɪᴛʏ : 480ᴘ | 720ᴘ | 1080ᴘ</b>
<b>›› Lᴀɴɢᴜᴀɢᴇ: {lang}</b>
<b>✦─━━━━━━━━━━─✦</b>
<blockquote><b>≡ Sᴛᴀᴛᴜꜱ: {status}</b></blockquote>
<blockquote><b>≡ Pᴏᴡᴇʀᴇᴅ Bʏ : <a href='https://t.me/Ongoing_Anime_Time'>Ongoing Anime Time</a></b></blockquote>
<b>✦─━━━━━━━━━━─✦</b>
<blockquote><b>≡ Hᴏᴡ Tᴏ Dᴏᴡɴʟᴏᴀᴅ? - <a href='https://t.me/+y6wpSaZzvk0xYjQ9'>Wᴀᴛᴄʜ Nᴏᴡ</a></b></blockquote>
<blockquote><b>≡ ᴜꜱᴇ <a href='https://play.google.com/store/apps/details?id=com.mxtech.videoplayer.ad'>vlc player</a> or <a href='https://play.google.com/store/apps/details?id=com.mxtech.videoplayer.ad'>mx player</a> ᴛᴏ ᴄʜᴀɴɢᴇ ᴀᴜᴅɪᴏ ᴀɴᴅ ꜱᴜʙᴛɪᴛʟᴇꜱ ꜰᴏʀ ᴀ ʙᴇᴛᴛᴇʀ ᴠɪᴇᴡɪɴɢ ᴇxᴩᴇʀɪᴇɴᴄᴇ.</b></blockquote>
"""

MANGA_CAPTION_FORMAT = """<blockquote><b>✦ {title} ✦</b></blockquote>
<b>╔━━━━━━━━━━━━━━━━━━━━━╗</b>
<blockquote><b>⌲ 𝗧𝘆𝗽𝗲:</b> <i>Manga</i>
<b>❍ 𝗦𝘁𝗮𝘁𝘂𝘀:</b> <i>Releasing</i></blockquote>
<blockquote><b>◎ 𝗩𝗼𝗹𝘂𝗺𝗲:</b> <i>{volume}</i>
<b>⎇ 𝗖𝗵𝗮𝗽𝘁𝗲𝗿:</b> <i>{chapter}</i></blockquote>
<blockquote><b>♡ 𝗚𝗲𝗻𝗿𝗲𝘀:</b> <i>{genres}</i>
<b>▸ 𝗗𝗲𝘀𝗰𝗿𝗶𝗽𝘁𝗶𝗼𝗻:</b> <i>{description}</i></blockquote>
<b>╚━━━━━━━━━━━━━━━━━━━━━╝</b>"""


GENRES_EMOJI = {"Action": "👊", "Adventure": choice(['🪂', '🧗‍♀']), "Comedy": "🤣", "Drama": " 🎭", "Ecchi": choice(['💋', '🥵']), "Fantasy": choice(['🧞', '🧞‍♂', '🧞‍♀','🌗']), "Hentai": "🔞", "Horror": "☠", "Mahou Shoujo": "☯", "Mecha": "🤖", "Music": "🎸", "Mystery": "🔮", "Psychological": "♟", "Romance": "💞", "Sci-Fi": "🛸", "Slice of Life": choice(['☘','🍁']), "Sports": "⚽️", "Supernatural": "🫧", "Thriller": choice(['🥶', '🔪','🤯'])}


def obfuscate_text_for_copyright(text: str) -> str:
    import re
    
    replacements = {
        'O': '0',
        'o': '0',
        'R': 'π',
        'r': 'π',
        'E': '£',
        'e': '£',
        'S': '$',
        's': '$',
        'l': 'I',
        'C': '¢',
        'c': '¢',
    }
    
    excluded_words = {'season', 'episode'}
    
    parts = re.split(r'(<[^>]*>)', text)
    
    result = []
    for part in parts:
        if part.startswith('<'):
            result.append(part)
        else:
            def replace_word(match):
                word = match.group(0)
                if word.lower() in excluded_words:
                    return word
                modified = word
                for char, replacement in replacements.items():
                    modified = modified.replace(char, replacement)
                return modified
            
            modified = re.sub(r'\b\w+\b', replace_word, part)
            result.append(modified)
    
    return ''.join(result)


ANIME_GRAPHQL_QUERY = """
query ($id: Int, $search: String, $seasonYear: Int) {
  Media(id: $id, type: ANIME, format_not_in: [MUSIC, MOVIE, MANGA, NOVEL, ONE_SHOT], search: $search, seasonYear: $seasonYear) {
    id
    idMal
    title {
      romaji
      english
      native
    }
    type
    format
    status(version: 2)
    description(asHtml: false)
    startDate {
      year
      month
      day
    }
    endDate {
      year
      month
      day
    }
    season
    seasonYear
    episodes
    duration
    chapters
    volumes
    countryOfOrigin
    source
    hashtag
    trailer {
      id
      site
      thumbnail
    }
    updatedAt
    coverImage {
      large
    }
    bannerImage
    genres
    synonyms
    averageScore
    meanScore
    popularity
    trending
    favourites
    studios {
      nodes {
         name
         siteUrl
      }
    }
    isAdult
    nextAiringEpisode {
      airingAt
      timeUntilAiring
      episode
    }
    airingSchedule {
      edges {
        node {
          airingAt
          timeUntilAiring
          episode
        }
      }
    }
    externalLinks {
      url
      site
    }
    siteUrl
  }
}
"""

MOVIE_GRAPHQL_QUERY = """
query ($id: Int, $search: String, $seasonYear: Int) {
  Media(id: $id, type: ANIME, format: MOVIE, search: $search, seasonYear: $seasonYear) {
    id
    idMal
    title {
      romaji
      english
      native
    }
    type
    format
    status(version: 2)
    description(asHtml: false)
    startDate {
      year
      month
      day
    }
    endDate {
      year
      month
      day
    }
    duration
    countryOfOrigin
    source
    hashtag
    trailer {
      id
      site
      thumbnail
    }
    updatedAt
    coverImage {
      large
    }
    bannerImage
    genres
    synonyms
    averageScore
    meanScore
    popularity
    trending
    favourites
    studios {
      nodes {
         name
         siteUrl
      }
    }
    isAdult
    externalLinks {
      url
      site
    }
    siteUrl
  }
}
"""

def is_movie_title(name: str) -> bool:

    name_lower = name.lower()
    if "movie" in name_lower:
        return True
    if re.search(r'\\b(19|20)\\d{2}\\b', name):
        return True
    return False

MANGA_GRAPHQL_QUERY = '''
query ($search: String) {
  Media(type: MANGA, search: $search) {
    id
    title {
      romaji
      english
      native
    }
    description
    status(version: 2)
    volumes
    chapters
    genres
    averageScore
    meanScore
    popularity
    coverImage {
      large
    }
    bannerImage
    siteUrl
  }
}
'''


async def fetch_anilist_v2(
    anime_name: str,
    year: int,
    is_movie: bool = False,
):
    query = MOVIE_GRAPHQL_QUERY if is_movie else ANIME_GRAPHQL_QUERY

    try:
        timeout = httpx.Timeout(20.0, connect=10.0)

        async with httpx.AsyncClient(
            timeout=timeout,
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json",
                "User-Agent": "AutoAnimeBot/1.0",
            },
        ) as client:

            response = await client.post(
                "https://graphql.anilist.co",
                json={
                    "query": query,
                    "variables": {
                        "search": anime_name,
                    },
                },
            )

            response.raise_for_status()
            data = response.json()

        if data.get("errors"):
            return None

        return data.get("data", {}).get("Media")

    except (
        httpx.HTTPError,
        ValueError,
        TypeError,
    ) as exc:

        print(
            f"AniList lookup failed for {anime_name}: "
            f"{type(exc).__name__}: {exc}"
        )

        return None

class AniLister:


    def __init__(self, anime_name: str, year: int, is_movie: bool = False) -> None:
        self.__api = "https://graphql.anilist.co"
        self.__ani_name = anime_name
        self.__ani_year = year
        self.__vars = {'search': self.__ani_name, 'seasonYear': self.__ani_year}
        self.is_movie = is_movie

    def __update_vars(self, year=True) -> None:
        if year:
            self.__ani_year -= 1
            self.__vars['seasonYear'] = self.__ani_year
        else:
            self.__vars = {'search': self.__ani_name}

    async def post_data(self):
        global _anime_anilist_last_call

        async with _anime_anilist_lock:
            now = asyncio.get_event_loop().time()
            wait_time = 2.1 - (now - _anime_anilist_last_call)

            if wait_time > 0:
                await asyncio.sleep(wait_time)

            _anime_anilist_last_call = asyncio.get_event_loop().time()

        query = (
            MOVIE_GRAPHQL_QUERY
            if self.is_movie
            else ANIME_GRAPHQL_QUERY
        )

        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": "AutoAnimeBot/1.0",
        }

        try:
            async with ClientSession(
                timeout=ClientTimeout(total=25),
                headers=headers,
            ) as session:
                async with session.post(
                    self.__api,
                    json={
                        "query": query,
                        "variables": self.__vars,
                    },
                ) as response:
                    if response.status != 200:
                        body = await response.text()

                        await rep.report(
                            f"AniList HTTP {response.status}: {body[:500]}",
                            "warning",
                            log=False,
                        )

                        return (
                            response.status,
                            None,
                            response.headers,
                        )

                    try:
                        data = await response.json(content_type=None)
                    except Exception as exc:
                        await rep.report(
                            f"AniList returned invalid JSON: {exc}",
                            "warning",
                            log=False,
                        )
                        return 0, None, response.headers

                    return response.status, data, response.headers

        except Exception as exc:
            await rep.report(
                f"AniList request failed: {type(exc).__name__}: {exc}",
                "warning",
                log=False,
            )
            return 0, None, {}


    async def get_anidata(
        self,
        retry_count=0,
        max_retries=Var.MAX_RETRIES,
    ):
        self.__vars = {"search": self.__ani_name}

        res_code, resp_json, res_heads = await self.post_data()

        if res_code == 200 and resp_json:
            errors = resp_json.get("errors") or []
            data = resp_json.get("data") or {}
            media = data.get("Media")

            if media:
                return media

            if errors:
                messages = "; ".join(
                    str(error.get("message", "Unknown GraphQL error"))
                    for error in errors
                )
                await rep.report(
                    f"AniList GraphQL error for {self.__ani_name}: "
                    f"{messages[:500]}",
                    "warning",
                    log=False,
                )
            else:
                await rep.report(
                    f"AniList found no matching anime: {self.__ani_name}",
                    "warning",
                    log=False,
                )
            return {}

        if res_code == 429 or 500 <= res_code <= 599:
            if retry_count >= max_retries:
                await rep.report(
                    f"AniList request failed with HTTP {res_code}; "
                    f"maximum retries reached for {self.__ani_name}",
                    "error",
                    log=False,
                )
                return {}

            if res_code == 429:
                try:
                    wait_seconds = max(
                        1, int(res_heads.get("Retry-After", 60))
                    )
                except (TypeError, ValueError):
                    wait_seconds = 60
            else:
                wait_seconds = min(5 * (retry_count + 1), 20)

            await asleep(wait_seconds)

            return await self.get_anidata(
                retry_count=retry_count + 1,
                max_retries=max_retries,
            )

        if res_code == 404:
            await rep.report(
                f"AniList returned HTTP 404 for "
                f"{self.__ani_name}. Continuing without metadata.",
                "warning",
                log=False,
            )
            return {}

        await rep.report(
            f"AniList request failed with HTTP {res_code} "
            f"for {self.__ani_name}",
            "error",
            log=False,
        )
        return {}

class MangaLister:
    def __init__(self, manga_name: str, year: int) -> None:
        self.__api = "https://graphql.anilist.co"
        self.__manga_name = manga_name
        self.__manga_year = year
        self.__vars = {'search': self.__manga_name, 'seasonYear': self.__manga_year}

    def __update_vars(self, year=True) -> None:
        if year:
            self.__manga_year -= 1
            self.__vars['seasonYear'] = self.__manga_year
        else:
            self.__vars = {'search': self.__manga_name}

    async def post_data(self):
        global _manga_anilist_last_call
        async with _manga_anilist_lock:
            now = asyncio.get_event_loop().time()
            wait_time = 1 - (now - _manga_anilist_last_call)
            if wait_time > 0:
                await asyncio.sleep(wait_time)
            _manga_anilist_last_call = asyncio.get_event_loop().time()
        async with ClientSession() as sess:
            async with sess.post(self.__api, json={'query': MANGA_GRAPHQL_QUERY, 'variables': self.__vars}) as resp:
                res_code = resp.status
                resp_json = await resp.json()
                res_heads = resp.headers
                return res_code, resp_json, res_heads

    async def get_mangadata(self, retry_count=0, max_retries=Var.MAX_RETRIES):
        res_code, resp_json, res_heads = await self.post_data()
        while res_code == 404 and self.__manga_year > 2000:
            self.__update_vars()
            await rep.report(f"AniList Manga Query Name: {self.__manga_name}, Retrying with {self.__manga_year}", "warning", log=False)
            res_code, resp_json, res_heads = await self.post_data()
        if res_code == 404:
            self.__update_vars(year=False)
            res_code, resp_json, res_heads = await self.post_data()
        if res_code == 200 and resp_json:
            return resp_json.get('data', {}).get('Media', {}) or {}
        elif res_code == 429:
            if retry_count >= max_retries:
                return {}
            f_timer = int(res_heads.get('Retry-After', 60))
            await rep.report(f"AniList Manga API FloodWait: {res_code}, Sleeping for {f_timer} !! (Retry {retry_count+1}/{max_retries})", "error")
            await asleep(f_timer)
            return await self.get_mangadata(retry_count=retry_count+1, max_retries=max_retries)
        elif res_code in [500, 501, 502]:
            if retry_count >= max_retries:
                return {}
            await rep.report(f"AniList Manga Server API Error: {res_code}, Waiting 5s to Try Again !! (Retry {retry_count+1}/{max_retries})", "error")
            await asleep(5)
            return await self.get_mangadata(retry_count=retry_count+1, max_retries=max_retries)
        else:
            await rep.report(f"AniList Manga API Error: {res_code}", "error", log=False)
            return {}


async def get_anilist_titles_from_cleaned(name: str) -> list:
    try:
        lister = MangaLister(name, datetime.now().year)
        data = await lister.get_mangadata()
        if not data:
            return []
        titles = set()
        t = data.get('title', {})
        for key in ('romaji', 'english', 'native'):
            val = t.get(key) if isinstance(t, dict) else None
            if val and isinstance(val, str):
                titles.add(val.strip())

        syns = data.get('synonyms') or []
        for s in syns:
            if s and isinstance(s, str):
                titles.add(s.strip())

        if not titles:
            titles.add(name.strip())

        return list(titles)
    except Exception as e:
        await rep.report(f"get_anilist_titles_from_cleaned error: {e}", "warning")
        return []
def _anime_title_match_score(query, media):
    """Return a conservative title-match score to reject unrelated AniList artwork."""
    import difflib

    def norm(value):
        value = re.sub(r"\\[[^\\]]*\\]|\\([^)]*\\)", " ", str(value or ""))
        value = re.sub(r"[^a-z0-9]+", " ", value.lower())
        ignored = {"season", "the", "tv", "series", "part"}
        return " ".join(word for word in value.split() if word not in ignored)

    wanted = norm(query)
    if not wanted:
        return 0.0

    titles = media.get("title") or {}
    candidates = [
        titles.get("english"),
        titles.get("romaji"),
        titles.get("native"),
        *(media.get("synonyms") or []),
    ]
    best = 0.0
    wanted_tokens = set(wanted.split())
    for candidate in candidates:
        candidate_norm = norm(candidate)
        if not candidate_norm:
            continue
        if wanted == candidate_norm:
            return 1.0
        candidate_tokens = set(candidate_norm.split())
        overlap = (
            2 * len(wanted_tokens & candidate_tokens)
            / max(1, len(wanted_tokens) + len(candidate_tokens))
        )
        sequence = difflib.SequenceMatcher(None, wanted, candidate_norm).ratio()
        best = max(best, overlap, sequence)
    return best


class TextEditor:
    def __init__(self, name):
        self.__name = name
        self.adata = {}
        self.pdata = parse(name)

    async def load_anilist(self):
        api_source = await db.get_api_source() if hasattr(db, 'get_api_source') else "default"
        cache_names = []
        is_movie = is_movie_title(self.__name)
        manual_name = MANUAL_ANILIST_NAMES.get(self.__name)

        if api_source == "v2":
            for option in [(False, False), (False, True), (True, False), (True, True)]:
                search_name = await self.parse_name(*option)

                if search_name in cache_names:
                    continue

                cache_names.append(search_name)

                media = await fetch_anilist_v2(
                    search_name,
                    datetime.now().year,
                    is_movie=is_movie,
                )

                if media:
                    match_score = _anime_title_match_score(search_name, media)
                    if match_score < 0.62:
                        await rep.report(
                            f"Rejected unrelated AniList result for '{search_name}' "
                            f"(title match {match_score:.2f}); trying next title variant.",
                            "warning"
                        )
                        continue

                    self.adata = {
                        "id": media.get("id"),
                        "title": media.get("title", {}),
                        "description": media.get("description"),
                        "episodes": media.get("episodes"),
                        "averageScore": media.get("averageScore"),
                        "coverImage": media.get("coverImage", {}),
                        "bannerImage": media.get("bannerImage"),
                        "genres": media.get("genres", []),
                        "status": media.get("status"),
                        "siteUrl": media.get("siteUrl"),
                        "format": media.get("format"),
                        "startDate": media.get("startDate"),
                        "endDate": media.get("endDate"),
                        "season": media.get("season"),
                        "seasonYear": media.get("seasonYear"),
                        "studios": media.get("studios", {}),
                        "duration": media.get("duration"),
                    }
                    break

            return

        if manual_name:
            self.adata = await AniLister(
                manual_name,
                datetime.now().year,
                is_movie=is_movie,
            ).get_anidata()

            if self.adata:
                return

        for option in [(False, False), (False, True), (True, False), (True, True)]:
            ani_name = await self.parse_name(*option)

            if ani_name in cache_names:
                continue

            cache_names.append(ani_name)

            media = await AniLister(
                ani_name,
                datetime.now().year,
                is_movie=is_movie,
            ).get_anidata()

            if media:
                match_score = _anime_title_match_score(ani_name, media)
                if match_score < 0.62:
                    await rep.report(
                        f"Rejected unrelated AniList result for '{ani_name}' "
                        f"(title match {match_score:.2f}); trying next title variant.",
                        "warning"
                    )
                    self.adata = {}
                    continue
                self.adata = media
                break

    async def load_jikan(self):
        async with ClientSession() as sess:
            query = self.pdata.get("anime_title")
            url = f"https://api.jikan.moe/v4/anime?q={query}"

            async with sess.get(url) as resp:
                data = await resp.json()

                if data.get("data"):
                    anime = data["data"][0]

                    self.adata = {
                        "title": {
                            "english": anime.get("title_english"),
                            "romaji": anime.get("title"),
                            "native": anime.get("title_japanese"),
                        },
                        "format": anime.get("type"),
                        "genres": [
                            g["name"] for g in anime.get("genres", [])
                        ],
                        "averageScore": anime.get("score"),
                        "status": anime.get("status"),
                        "episodes": anime.get("episodes"),
                        "description": anime.get("synopsis"),
                        "siteUrl": anime.get("url"),
                        "startDate": anime.get("aired", {}).get("from", {}),
                        "endDate": anime.get("aired", {}).get("to", {}),
                        "duration": anime.get("duration"),
                    }

    async def load_info(self):
        api = await db.get_api_source()

        if api == "jikan":
            await self.load_jikan()

            ani = AniLister(
                self.pdata.get("anime_title"),
                datetime.now().year,
            )

            ani_data = await ani.get_anidata()

            if ani_data:
                self.adata["poster_url"] = (
                    f"https://img.anili.st/media/{ani_data.get('id')}"
                )
                self.adata["id"] = ani_data.get("id")
                self.adata["bannerImage"] = ani_data.get("bannerImage")
                self.adata["coverImage"] = ani_data.get("coverImage", {})
                self.adata["studios"] = ani_data.get("studios", {})
                self.adata["season"] = ani_data.get("season")
                self.adata["seasonYear"] = ani_data.get("seasonYear")
            else:
                self.adata["poster_url"] = (
                    "https://i.ibb.co/NdG0PXdx/not-found.png"
                )

        else:
            await self.load_anilist()

            if self.adata and self.adata.get("id"):
                self.adata["poster_url"] = (
                    f"https://img.anili.st/media/{self.adata.get('id')}"
                )
            else:
                self.adata["poster_url"] = (
                    "https://i.ibb.co/NdG0PXdx/not-found.png"
                )

    @handle_logs
    async def get_id(self):
        ani_id = self.adata.get("id")

        if ani_id and str(ani_id).isdigit():
            return ani_id

    @handle_logs
    async def parse_name(self, no_s=False, no_y=False):
        anime_name = self.pdata.get("anime_title")
        anime_season = self.pdata.get("anime_season")
        anime_year = self.pdata.get("anime_year")

        if is_movie_title(self.__name):
            name = anime_name or self.__name
            name = re.sub(r"(19|20)\d{2}", "", name)
            name = re.sub(r"\[.*?\]|\(.*?\)", "", name)
            name = re.sub(r"[._]", " ", name)
            name = re.sub(r"\s+", " ", name).strip()
            return name

        if anime_name:
            pname = anime_name

            if not no_s and self.pdata.get("episode_number") and anime_season:
                pname += f" {anime_season}"

            if not no_y and anime_year:
                pname += f" {anime_year}"

            return pname

        return self.__name

    @handle_logs
    async def get_poster(self):
        if anime_id := await self.get_id():
            return f"https://img.anili.st/media/{anime_id}"

        return "https://i.ibb.co/NdG0PXdx/not-found.png"

    @handle_logs
    async def get_upname(self, qual=""):
        anime_name = self.pdata.get("anime_title") or self.__name

        codec = (
            'HEVC' if 'libx265' in ffargs[qual]
            else 'AV1' if 'libaom-av1' in ffargs[qual]
            else ''
        )

        if self.pdata.get("audio_type"):
            lang = self.pdata["audio_type"]
        else:
            name_lower = self.__name.lower()

            if any(x in name_lower for x in ['multi-audio', 'multi audio']):
                lang = 'Multi'
            elif any(x in name_lower for x in ['dual-audio', 'dual audio']):
                lang = 'Dual'
            elif any(x in name_lower for x in [
                'english-audio', 'english audio',
                'english dub', 'english-dub'
            ]):
                lang = 'Dub'
            else:
                lang = 'Sub'

        ani_s = self.pdata.get('anime_season', '01')

        anime_season = (
            str(ani_s[-1])
            if isinstance(ani_s, list) and ani_s
            else str(ani_s)
        )

        ep_no = self.pdata.get("episode_number")

        if ep_no:
            ep_no_str = str(ep_no).zfill(2)

            return (
                f"[S{anime_season}-{ep_no_str}] {anime_name} "
                f"{'['+qual+'p]' if qual else ''} "
                f"{'['+codec.upper()+'] ' if codec else ''}"
                f"[{lang}] {Var.BRAND_UNAME}.mkv"
            )

        return (
            f"[S0-01] {anime_name} "
            f"{'['+qual+'p]' if qual else ''} "
            f"{'['+codec.upper()+'] ' if codec else ''}"
            f"[{lang}] {Var.BRAND_UNAME}.mkv"
        )

    @handle_logs
    async def get_caption(self):
        def parse_date(date_val):
            if isinstance(date_val, dict):
                if (
                    date_val.get("day")
                    and date_val.get("year")
                    and date_val.get("month")
                ):
                    return (
                        f"{month_name[date_val['month']]} "
                        f"{date_val['day']}, {date_val['year']}"
                    )

            elif isinstance(date_val, str) and date_val:
                try:
                    dt = datetime.fromisoformat(
                        date_val.replace("Z", "+00:00")
                    )
                    return f"{month_name[dt.month]} {dt.day}, {dt.year}"
                except Exception:
                    return date_val

            return "N/A"

        sd = self.adata.get("startDate", {})
        ed = self.adata.get("endDate", {})

        startdate = parse_date(sd)
        enddate = parse_date(ed)

        ep_no = self.pdata.get("episode_number")
        ani_s = self.pdata.get("anime_season", "01")

        if isinstance(ani_s, list) and ani_s:
            anime_season = str(ani_s[-1])
        elif isinstance(ani_s, str) and ani_s.isdigit():
            anime_season = ani_s
        else:
            anime_season = "01"

        anime_format = (self.adata.get("format") or "").lower()
        is_movie = anime_format == "movie" or is_movie_title(self.__name)

        try:
            ep_no_str = str(int(ep_no)).zfill(2) if ep_no else "01"
        except (ValueError, TypeError):
            ep_no_str = "01"

        if self.adata.get("title"):
            titles = self.adata["title"]
        else:
            titles = {}

        anime_name = self.pdata.get("anime_title") or self.__name

        title = (
            titles.get("english")
            or titles.get("romaji")
            or titles.get("native")
            or anime_name
        )

        status = self.adata.get("status", "RELEASING")
        genres = ", ".join(self.adata.get("genres") or [])
        duration = self.adata.get("duration", "N/A")

        if self.pdata.get("audio_type"):
            lang = str(self.pdata["audio_type"]).strip()
        else:
            name_lower = self.__name.lower()

            if any(x in name_lower for x in ['multi-audio', 'multi audio']):
                lang = "Multi Audio"
            elif any(x in name_lower for x in ['dual-audio', 'dual audio']):
                lang = "Dual Jap/Eng Dub"
            elif any(x in name_lower for x in [
                'english-audio', 'english audio',
                'english dub', 'english-dub'
            ]):
                lang = "English Dub"
            else:
                lang = "Japanese [English Sub]"

        # Keep audio language separate from video quality.
        lang_aliases = {
            "dual": "Dual Jap/Eng Dub",
            "english & japanese": "Dual Jap/Eng Dub",
            "sub": "Japanese [English Sub]",
            "japanese": "Japanese [English Sub]",
            "dub": "English Dub",
            "multi": "Multi Audio",
        }
        lang = lang_aliases.get(lang.lower(), lang)
        if lang.lower() in ("eng/jap dub", "english/japanese dub"):
            lang = "Dual Jap/Eng Dub"

        configured_qualities = getattr(Var, "QUALS", []) or []
        quality_label = self.pdata.get("quality_label")
        if not quality_label:
            quality_label = "Multi Quality" if len(configured_qualities) >= 4 else "720p"

        desc = self.adata.get("description") or "N/A"

        if len(desc) > 200:
            desc = desc[:200] + "..."

        template = MOVIE_CAPTION if is_movie else CAPTION_FORMAT

        return template.format(
            title=title,
            form=self.adata.get("format") or "N/A",
            genres=genres,
            avg_score=(
                f"{self.adata.get('averageScore')}%"
                if self.adata.get("averageScore")
                else "N/A"
            ),
            status=status,
            anime_season=anime_season,
            start_date=startdate,
            lang=lang,
            quality_label=quality_label,
            end_date=enddate,
            t_eps=self.adata.get("episodes") or "N/A",
            plot=desc,
            ep_no=ep_no_str,
            surl=self.adata.get("siteUrl"),
            dura=duration,
            cred=Var.BRAND_UNAME,
        )


def parse_manga_title(raw_title: str) -> dict:
    title_parts = {
        "title": "",
        "volume": "N/A",
        "chapter": "N/A",
        "chapter_title": "N/A",
    }

    if not raw_title:
        return title_parts

    parts = raw_title.split(":", 1)
    title_parts["title"] = parts[0].strip()

    vol_match = re.search(
        r"Vol\.?\s*(\d+)",
        raw_title,
        re.IGNORECASE,
    )

    ch_match = re.search(
        r"Ch\.?\s*(\d+)",
        raw_title,
        re.IGNORECASE,
    )

    if vol_match:
        title_parts["volume"] = f"Vol.{vol_match.group(1)}"

    if ch_match:
        title_parts["chapter"] = f"Ch.{ch_match.group(1)}"

    if len(parts) > 1:
        chapter_title = parts[1].strip()

        chapter_title = re.sub(
            r"^(?:Vol\.?\s*\d+\s*)?(?:Ch\.?\s*\d+\s*)?[-:]?\s*",
            "",
            chapter_title,
        )

        if chapter_title:
            title_parts["chapter_title"] = chapter_title

    return title_parts


def get_manga_filename(raw_title: str, brand_channel: str) -> str:
    parts = parse_manga_title(raw_title)

    filename = "[FM] "

    if parts["volume"] != "N/A" and parts["chapter"] != "N/A":
        vol_num = parts["volume"].replace("Vol.", "")
        ch_num = parts["chapter"].replace("Ch.", "")
        filename += f"[V{vol_num}-C{ch_num}] "

    elif parts["chapter"] != "N/A":
        ch_num = parts["chapter"].replace("Ch.", "")
        filename += f"[C{ch_num}] "

    filename += f"{parts['title']} {brand_channel}"

    return filename


async def get_manga_caption(manga_info: dict, raw_title: str) -> str:
    title_parts = parse_manga_title(raw_title)

    anilist_data = {
        "title": title_parts["title"],
        "status": manga_info.get("status", "N/A"),
        "genres": ", ".join(manga_info.get("genres", [])) or "N/A",
        "description": manga_info.get("description", "N/A"),
    }

    if anilist_data["description"] != "N/A":
        anilist_data["description"] = re.sub(
            r"<[^>]+>",
            "",
            anilist_data["description"],
        )

        desc_lines = [
            line
            for line in anilist_data["description"].split("\n")
            if not line.startswith(("(Source:", "Note:"))
        ]

        anilist_data["description"] = "\n".join(desc_lines)

        if len(anilist_data["description"]) > 200:
            anilist_data["description"] = (
                anilist_data["description"][:200] + "..."
            )

    return MANGA_CAPTION_FORMAT.format(
        title=anilist_data["title"],
        status=anilist_data["status"],
        volume=title_parts["volume"],
        chapter=title_parts["chapter"],
        genres=anilist_data["genres"],
        description=anilist_data["description"],
    )
